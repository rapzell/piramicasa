import "./globals.css";
import type { ReactNode } from "react";
import { SITE_ORIGIN } from "../lib/site";

export const metadata = {
  "metadataBase": new URL(SITE_ORIGIN || "http://localhost:3000"),
  "title": "VISITA PIRAMICASA.ES Ciencia y Técnica de las Pirámides",
  "description": "VISITA PIRAMICASA.ES Ciencia y Técnica de las Pirámides",
  "keywords": [
    "proporcion",
    "proporciones piramidales",
    "pirámides",
    "medidas",
    "fabricacion",
    "piramidal",
    "formula",
    "terapia piramidal"
  ],
  "robots": "INDEX,FOLLOW"
};
export const viewport = {
  "width": "device-width",
  "initialScale": 1
};


export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang={"es"}>
      <body className="cn0" data-cid="n0">
        {children}
      </body>
    </html>
  );
}
